//
//  Constants.swift
//  nemt
//
//  Created by user on 18/02/19.
//  Copyright © 2019 Abin. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

extension String {
    
    /*
     Webservice URLs and Names
     */
    public static var baseUrlProd            = "https://reqres.in/"
    public static var user                   = "api/users?page=2"
    
}

/*
 API Completion Handler
 */

typealias success = (JSON) -> ()
typealias failure = (Error) -> ()
typealias wsHandler = (_ success: Bool, _ response: Any?) -> ()

let defaults = UserDefaults.standard
