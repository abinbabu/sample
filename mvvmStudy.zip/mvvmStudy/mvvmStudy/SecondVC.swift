//
//  SecondVC.swift
//  mvvmStudy
//
//  Created by Abin on 29/02/20.
//  Copyright © 2020 Abin. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func dismiss(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
