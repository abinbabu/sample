//
//  modeClass.swift
//  mvvmStudy
//
//  Created by Abin on 29/02/20.
//  Copyright © 2020 Abin. All rights reserved.
//

import Foundation

struct RootClass: Codable {

    let page: Int
    let perPage: Int
    let total: Int
    let totalPages: Int
    let data: [Data]

    private enum CodingKeys: String, CodingKey {
        case page = "page"
        case perPage = "per_page"
        case total = "total"
        case totalPages = "total_pages"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        page = try values.decode(Int.self, forKey: .page)
        perPage = try values.decode(Int.self, forKey: .perPage)
        total = try values.decode(Int.self, forKey: .total)
        totalPages = try values.decode(Int.self, forKey: .totalPages)
        data = try values.decode([Data].self, forKey: .data)
    }

}

struct Data: Codable {

    let id: Int
    let email: String
    let firstName: String
    let lastName: String
    let avatar: String

    private enum CodingKeys: String, CodingKey {
        case id = "id"
        case email = "email"
        case firstName = "first_name"
        case lastName = "last_name"
        case avatar = "avatar"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(Int.self, forKey: .id)
        email = try values.decode(String.self, forKey: .email)
        firstName = try values.decode(String.self, forKey: .firstName)
        lastName = try values.decode(String.self, forKey: .lastName)
        avatar = try values.decode(String.self, forKey: .avatar)
    }

}
