//
//  ViewController.swift
//  mvvmStudy
//
//  Created by Abin on 29/02/20.
//  Copyright © 2020 Abin. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {

    
    var arr = [Data]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        WebserviceManager.shared.getWS(.user, isHeader: false) { (success, response) in
            DispatchQueue.main.async {
                if success{
                    
                    let decoder = JSONDecoder()
                    let data = JSON(response as Any)
                    
                    
                    do{
                        let  jsonData = try JSONSerialization.data(withJSONObject: data.object)
                        do {
                            let response = try decoder.decode(RootClass.self, from:jsonData )
                            self.arr.append(contentsOf: response.data)
//                            print(self.arr)
                            } catch {
                             print("Parsing Failed")
                            }
                        

                    } catch _ {
                        print ("UH OOO")
                    }
                   
                    
                    
                }
                else {
                    print("error as any")
                }
            }
        }
        
        
        
    }

}

