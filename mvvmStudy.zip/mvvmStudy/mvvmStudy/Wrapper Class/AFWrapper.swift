//
//  AFWrapper.swift
//  nemt
//
//  Created by user on 18/02/19.
//  Copyright © 2019 Abin. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import SwiftyJSON


class AFWrapper {
    
    //Webservice for GET Request with parameters
    
    class func requestGETURL(_ url: String, params: [String: Any]?,isHeader: Bool, onSuccess success: @escaping success, onFailure failure: @escaping failure) {
        
        let userDefault = UserDefaults.standard
        let authToken = userDefault.value(forKey: "AuthToken") as? String
        var header: HTTPHeaders? = [:]
        if isHeader {
            header = ["Auth": authToken ?? ""]
        }
        
        AF.request(.baseUrlProd + url, method: .get, parameters: params, encoding: JSONEncoding.default, headers: header).validate().responseJSON { response in
            
//            if response.result {
//                guard let resultValue = response.result.value else {
//                    return
//                }
//                let resJSON = JSON(resultValue)
//                success(resJSON)
//
//            } else {
//                guard let error = response.result.error else {
//                    return
//                }
//                failure(error)
//            }
            
            switch response.result {
            case .success(let value):
                     let resJSON = JSON(value)
                     success(resJSON)
            case .failure(let error): break
                // error handling
            }
            
        }
    }
    
}
